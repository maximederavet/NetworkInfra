In this laboratory, pc1 and pc2 are not directly reachable (their distance is 1 hop).
Packets sent by from pc1 to pc2 need to be routed and forwarded by r1.
Therefore, we need to instruct pc1 that, in order to reach pc2, it need to go through r1.
This could be accomplished by setting on pc1 a default route via r1. Viceversa for pc2